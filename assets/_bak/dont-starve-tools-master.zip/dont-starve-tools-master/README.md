[![](https://img.shields.io/github/stars/handsomematt/dont-starve-tools.svg?style=social&label=Star)]()
[![](https://img.shields.io/github/release/handsomematt/dont-starve-tools.svg)]()
[![](https://img.shields.io/github/license/handsomematt/dont-starve-tools.svg)]()

## Synopsis

Klei Studio is a simple suite of tools for Don't Starve (and can be used for their other games too).

Note: These tools are old and unmaintained and may contain bugs. You should really use the official tools instead.

## Quick start

* [Download the latest release](https://github.com/handsomematt/dont-starve-tools/releases).

## Contributing

If you would like to contribute bug fixes and the likes, just make a pull request.

## Copyright and license

Copyright 2013-2018 Matt Stevens under [the MIT license](LICENSE).
