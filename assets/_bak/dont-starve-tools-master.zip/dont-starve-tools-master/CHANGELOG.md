Future changelogs can be found here: https://github.com/handsomematt/dont-starve-tools/releases

KleiStudio 1.3 ( 01/06/2013 ):
* Applied MIT license to all parts of the project, you can do whatever you want with it now!

* TEXCreator:
	* Added ability to premultiply alpha. Thanks @Ipsquiggle!


TEXTool 1.2 ( Underground Update ):
* Split the texture conversion into it's own unique tool.
* No longer relies on TextureConverter, saving is independent.
* Updated for the Underground update. ( Textures will have to be reconverted! )

TEXTool 1.1:
* Can now convert PNG -> TEX.
* Redone interface.
* Major bug fixes with reading files.

Pre Klei Studio ( TEXTool ):

1.0.2.0:
* You can now open a file with TEXTool by dragging a file onto the .exe
* Fixed a bug where double clicking an item in the file dialog.. Would do nothing.
* General stability bugs.

1.0.1.0:
* Added new save formats:
	* BMP
	* GIF
	* JPEG
	* PNG
* Hotkeys:
	* Ctrl + O: Open
	* Ctrl + S: Save
	* Ctrl + +: Zoom In
	* Ctrl + -: Zoom Out
* Small minor adjustments to the UI to make it easier to use.

1.0.0.0: Initial Release