---
author: "Hugo Authors"
title: "Emoji 支持指南"
date: "2019-03-05"
description: "Hugo 项目中 Emoji 的使用指南"
tags: ["emoji"]
ShowToc: false
ShowBreadCrumbs: false
---

在 Hugo 项目中可通过多种方式启用 Emoji 支持。

<!--more-->

您可以直接在模板或[行内短代码](https://gohugo.io/templates/shortcode-templates/#inline-shortcodes)中调用 [`emojify`](https://gohugo.io/functions/emojify/) 函数。

如需全局启用 Emoji，请在站点[配置文件](https://gohugo.io/getting-started/configuration/)中设置 `enableEmoji` 为 `true`，此后即可直接在内容文件中输入 Emoji 快捷代码，例如：

<p><span class="nowrap"><span class="emojify">🙈</span> <code>:see_no_evil:</code></span>  <span class="nowrap"><span class="emojify">🙉</span> <code>:hear_no_evil:</code></span>  <span class="nowrap"><span class="emojify">🙊</span> <code>:speak_no_evil:</code></span></p>
<br>

[Emoji 速查表](http://www.emoji-cheat-sheet.com/)是查找 Emoji 快捷代码的实用参考。

---

**注意**：上述步骤可在 Hugo 中启用 Unicode 标准 Emoji 字符和序列，但具体显示效果取决于浏览器和平台。如需自定义 Emoji 样式，可使用第三方 Emoji 字体或字体栈，例如：

{{< highlight html >}}
.emoji {
font-family: Apple Color Emoji, Segoe UI Emoji, NotoColorEmoji, Segoe UI Symbol, Android Emoji, EmojiSymbols;
}
{{< /highlight >}}

{{< css.inline >}}

<style>
.emojify {
	font-family: Apple Color Emoji, Segoe UI Emoji, NotoColorEmoji, Segoe UI Symbol, Android Emoji, EmojiSymbols;
	font-size: 2rem;
	vertical-align: middle;
}
@media screen and (max-width:650px) {
  .nowrap {
    display: block;
    margin: 25px 0;
  }
}
</style>

{{< /css.inline >}}
