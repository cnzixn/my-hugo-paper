---
author: ["Hugo Authors", "PaperMod Contributors"]
title: "富内容与短代码"
date: "2019-03-10"
description: "Hugo短代码功能简述"
tags: ["markdown", "shortcodes", "privacy"]
ShowToc: true
---

Hugo内置了多种[富内容短代码](https://gohugo.io/content-management/shortcodes/#use-hugos-built-in-shortcodes)，并支持[隐私配置](https://gohugo.io/about/hugo-and-gdpr/)和提供无需JavaScript的静态社交媒体嵌入方案。

<!--more-->

---

## 图像短代码 ([PaperMod增强版](https://github.com/adityatelange/hugo-PaperMod/commits/master/layouts/shortcodes/figure.html))

{{< figure src="https://images.unsplash.com/photo-1702382930514-9759f4ca5469?q=80&w=1155&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA==" attr="Photo by [Aditya Telange](https://unsplash.com/@adityatelange?utm_content=creditCopyText&utm_medium=referral&utm_source=unsplash) on [Unsplash](https://unsplash.com/photos/a-person-sitting-on-a-rock-wall-looking-out-at-the-ocean-Z0lL0okYjy0)" align=center link="https://unsplash.com/photos/a-person-sitting-on-a-rock-wall-looking-out-at-the-ocean-Z0lL0okYjy0" target="_blank" >}}

---

## YouTube嵌入

{{< youtube hjD9jTi_DQ4 >}}

---

## Twitter短代码

{{< x user="adityatelange" id="1724414854348357922" >}}

---

## Vimeo短代码

vimeo 152985022

