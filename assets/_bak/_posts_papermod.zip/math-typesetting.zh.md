---
author: Hugo Authors  
title: 数学公式排版  
date: 2019-03-08  
description: 简要指南：如何配置KaTeX  
math: true  
ShowBreadCrumbs: false  

---

在Hugo项目中启用数学公式排版，需借助第三方JavaScript库。

<!--more-->

本示例将使用[KaTeX](https://katex.org/)：

1. **创建局部模板**  
   在`/layouts/partials/`目录下新建`math.html`文件

2. **引用脚本**  
   在此局部模板中引用[自动渲染扩展](https://katex.org/docs/autorender.html)，或本地托管相关脚本

3. **引入模板**  
   在主题模板（如[`extend_head.html`](../papermod/papermod-faq/#custom-head--footer)）中添加如下代码：  
   （参考[ISSUE #236](https://github.com/adityatelange/hugo-PaperMod/issues/236)）

```bash
{{ if or .Params.math .Site.Params.math }}
{{ partial "math.html" . }}
{{ end }}
```

4. **启用配置**  
   - 全局启用：在项目配置中设置`math: true`  
   - 单页启用：在文章Front Matter中添加`math: true`

**注意**：请参考[KaTeX支持的TeX函数列表](https://katex.org/docs/supported.html)

{{< math.inline >}}
{{ if or .Page.Params.math .Site.Params.math }}

<!-- KaTeX -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.11.1/dist/katex.min.css" integrity="sha384-zB1R0rpPzHqg7Kpt0Aljp8JPLqbXI3bhnPWROx27a9N0Ll6ZP/+DiW/UqRcLbRjq" crossorigin="anonymous">
<script defer src="https://cdn.jsdelivr.net/npm/katex@0.11.1/dist/katex.min.js" integrity="sha384-y23I5Q6l+B6vatafAwxRu/0oK/79VlbSz7Q9aiSZUvyWYIYsd+qj+o24G5ZU2zJz" crossorigin="anonymous"></script>
<script defer src="https://cdn.jsdelivr.net/npm/katex@0.11.1/dist/contrib/auto-render.min.js" integrity="sha384-kWPLUVMOks5AQFrykwIup5lo0m3iMkkHrD0uJ4H5cjeGihAutqP0yW0J6dpFiVkI" crossorigin="anonymous" onload="renderMathInElement(document.body);"></script>
{{ end }}
{{</ math.inline >}}

### 公式示例

{{< math.inline >}}

<p>
行内公式：\(\varphi = \dfrac{1+\sqrt5}{2}= 1.6180339887…\)
</p>
{{</ math.inline >}}

块级公式：

$$
 \varphi = 1+\frac{1} {1+\frac{1} {1+\frac{1} {1+\cdots} } }
$$
