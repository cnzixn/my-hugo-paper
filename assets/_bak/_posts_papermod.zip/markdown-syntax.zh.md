---
author: "Hugo Authors"
title: "Markdown 语法指南"
date: "2019-03-11"
description: "示例文章展示Hugo内容文件中使用的基础Markdown语法及HTML元素的CSS样式效果"
tags: ["markdown", "css", "html", "themes"]
categories: ["主题", "语法"]
series: ["主题指南"]
aliases: ["migrate-from-jekyl"]
cover:
  image: images/msg.png
  caption: "使用 [Vercel的OG图片生成器](https://og-playground.vercel.app/) 创建"
ShowToc: true
TocOpen: false
---

本文演示 Hugo 内容文件中使用的基础 Markdown 语法，并展示 Hugo 主题对 HTML 元素的 CSS 样式修饰效果。

<!--more-->

## 标题层级

HTML `<h1>`—`<h6>` 元素对应六个层级的标题，`<h1>` 为最高级标题，`<h6>` 为最低级。

# H1

## H2

### H3

#### H4

##### H5

###### H6

## 段落文本

Xerum, quo qui aut unt expliquam qui dolut labo. Aque venitatiusda cum, voluptionse latur sitiae dolessi aut parist aut dollo enim qui voluptate ma dolestendit peritin re plis aut quas inctum laceat est volestemque commosa as cus endigna tectur, offic to cor sequas etum rerum idem sintibus eiur? Quianimin porecus evelectur, cum que nis nust voloribus ratem aut omnimi, sitatur? Quiatem. Nam, omnis sum am facea corem alique molestrunt et eos evelece arcillit ut aut eos eos nus, sin conecerem erum fuga. Ri oditatquam, ad quibus unda veliamenimin cusam et facea ipsamus es exerum sitate dolores editium rerore eost, temped molorro ratiae volorro te reribus dolorer sperchicium faceata tiustia prat.

Itatur? Quiatae cullecum rem ent aut odis in re eossequodi nonsequ idebis ne sapicia is sinveli squiatum, core et que aut hariosam ex eat.

## 引用区块

### 无来源标注引用

> Tiam, ad mint andaepu dandae nostion secatur sequo quae.
> **注意** 可在引用块内使用 _Markdown语法_

### 带来源标注引用

> 不要通过共享内存来通信，而应通过通信来共享内存。
>
> — <cite>罗布·派克[^1]</cite>

[^1]: 此引文摘自罗布·派克在2015年11月18日Gopherfest大会上的[演讲](https://www.youtube.com/watch?v=PAAkCSZUG1c)

## 表格

| 姓名   | 年龄 |
| ------ | ---- |
| Bob    | 27   |
| Alice  | 23   |

### 表格内嵌Markdown

| 斜体       | 粗体       | 代码       |
| ---------- | ---------- | ---------- |
| _斜体文本_ | **粗体文本** | `代码片段` |

## 列表类型

### 有序列表

1. 第一项
2. 第二项
3. 第三项

### 无序列表

- 列表项
- 另一项
- 更多项

### 嵌套无序列表

- 水果
  - 苹果
  - 橙子
  - 香蕉
- 乳制品
  - 牛奶
  - 奶酪

### 嵌套有序列表

1. 水果
    - 苹果
    - 橙子
    - 香蕉
2. 乳制品
    1. 牛奶
    2. 奶酪
3. 第三类
    1. 子项一
    2. 子项二

## 特殊元素

<abbr title="图形交换格式">GIF</abbr> 是一种位图图像格式。

化学式：H<sub>2</sub>O

数学公式：X<sup>n</sup> + Y<sup>n</sup> = Z<sup>n</sup>

快捷键：<kbd><kbd>Ctrl</kbd>+<kbd>Alt</kbd>+<kbd>Del</kbd></kbd> 结束会话

荧光标记：大多数 <mark>蝾螈</mark> 是夜行性动物，捕食昆虫、蠕虫等小型生物