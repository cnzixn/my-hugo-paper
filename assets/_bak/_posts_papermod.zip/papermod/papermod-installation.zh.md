---
title: "安装/更新 PaperMod"
summary: 阅读关于安装和更新的说明以及示例配置模板
date: 2021-01-20
series: ["PaperMod"]
weight: 1
aliases: ["/papermod-installation"]
tags: ["PaperMod", "Docs"]
author: ["Aditya Telange"]
cover:
  image: images/papermod-cover.png
  hiddenInList: true
social:
  fediverse_creator: "@adityatelange@mastodon.social"
---

> - **以下所有示例我们将使用 `yml/yaml` 格式，建议使用 `yaml` 而非 `toml`，因为更易阅读。**
> - 如果需要，可以找到任何 [YML 转 TOML](https://www.google.com/search?q=yml+to+toml) 的转换工具。

---

## 快速开始 🚀

1. 按照 **[Hugo 文档 - 快速入门](https://gohugo.io/getting-started/quick-start/)** 指南安装 {{< inTextImg url="https://raw.githubusercontent.com/gohugoio/hugoDocs/master/static/img/hugo-logo.png" height="14" >}}。
   <br>（确保安装 **Hugo >= v0.112.4**）

2. 创建一个新的 {{< inTextImg url="https://raw.githubusercontent.com/gohugoio/hugoDocs/master/static/img/hugo-logo.png" height="14" >}} 站点
   ```sh
   hugo new site MyFreshWebsite --format yaml
   # 将 MyFreshWebsite 替换为你的网站名称
   ```
   注意：
   - 旧版本的 Hugo 可能不支持 `--format yaml`
   - 更多信息请阅读 [Hugo 文档 - hugo new site 命令](https://gohugo.io/commands/hugo_new_site/#synopsis)

创建新站点后，按照以下步骤添加 **PaperMod**

### 安装/更新 PaperMod

- 主题位于 `MyFreshWebsite/themes` 目录。
- PaperMod 将安装在 `MyFreshWebsite/themes/PaperMod`

> {{< collapse summary="**展开方法 1 - Git Clone**" >}}

**安装**：在你的 Hugo 站点文件夹 `MyFreshWebsite` 内运行：

```bash
git clone https://github.com/adityatelange/hugo-PaperMod themes/PaperMod --depth=1
```

如果需要固定到特定版本，可以在命令末尾添加 ` --branch v7.0`。

**更新**：在你的 Hugo 站点文件夹 `MyFreshWebsite` 内运行：

```bash
cd themes/PaperMod
git pull
```

{{</ collapse >}}

> {{< collapse summary="**展开方法 2 - Git Submodule（推荐）**" >}}

**安装**：在你的 Hugo 站点文件夹 `MyFreshWebsite` 内运行：

```bash
git submodule add --depth=1 https://github.com/adityatelange/hugo-PaperMod.git themes/PaperMod
git submodule update --init --recursive # 重新克隆仓库时需要（子模块可能不会自动克隆）
```

如果需要固定到特定版本，可以在命令末尾添加 ` --branch v7.0`。
更多关于 git 子模块的信息请阅读 [这里](https://www.atlassian.com/git/tutorials/git-submodule)。

**更新**：在你的 Hugo 站点文件夹 `MyFreshWebsite` 内运行：

```bash
git submodule update --remote --merge
```

{{</ collapse >}}

> {{< collapse summary="**展开方法 3 - 下载并解压**" >}}

从 Github Releases 下载 PaperMod 源码 Zip 文件，并解压到你的主题目录 `MyFreshWebsite/themes/PaperMod`。

直接下载链接：

- [Master Branch（最新版）](https://github.com/adityatelange/hugo-PaperMod/archive/master.zip)
- [v7.0](https://github.com/adityatelange/hugo-PaperMod/archive/v7.0.zip)
- [v6.0](https://github.com/adityatelange/hugo-PaperMod/archive/v6.0.zip)
- [v5.0](https://github.com/adityatelange/hugo-PaperMod/archive/v5.0.zip)
- [v4.0](https://github.com/adityatelange/hugo-PaperMod/archive/v4.0.zip)
- [v3.0](https://github.com/adityatelange/hugo-PaperMod/archive/v3.0.zip)
- [v2.0](https://github.com/adityatelange/hugo-PaperMod/archive/v2.0.zip)
- [v1.0](https://github.com/adityatelange/hugo-PaperMod/archive/v1.0.zip)

{{</ collapse >}}

> {{< collapse summary="**展开方法 4 - Hugo 模块**" >}}

**安装**：

- 在你的操作系统中安装 [Go 编程语言](https://go.dev/doc/install)。

- 初始化你自己的 Hugo 模块：

```
hugo mod init YOUR_OWN_GIT_REPOSITORY
```

- 在 `config.yml` 文件中添加 PaperMod：

```go {linenos=true}
module:
  imports:
  - path: github.com/adityatelange/hugo-PaperMod
```

**更新**：

```
hugo mod get -u
```

更多信息：[Hugo 文档 - HUGO 模块](https://gohugo.io/hugo-modules/use-modules/)

{{</ collapse >}}

### 最后在站点配置中将主题设置为 PaperMod

在 `config.yml` 中添加：

```yml {linenos=true}
theme: ["PaperMod"]
```

### 下一步 - 自定义 PaperMod 以适应你的偏好

- 首次设置后，你的站点将是空白的。
- 你可以查看本网站的源代码 - [PaperMod 示例站点的源代码](https://github.com/adityatelange/hugo-PaperMod/tree/exampleSite)
- 滚动到本页下方，你将找到关于每个部分的更多详细信息。
- 请阅读以下所有页面以了解如何配置 PaperMod。

---

## 支持 🫶

- 给 PaperMod 的 Github 仓库点个星 🌟。
- 通过在社交媒体上分享并向朋友推荐来帮助传播 PaperMod。🗣️
- 你也可以在 [Github Sponsors](https://github.com/sponsors/adityatelange) / [Ko-Fi](https://ko-fi.com/adityatelange) 上赞助 🏅。

---

## 关于 PaperMod 的视频

你可以观看 YouTube 上的几个视频，了解创建者的想法以及设置过程。

▶️ https://youtube.com/playlist?list=PLeiDFxcsdhUrzkK5Jg9IZyiTsIMvXxKZP

---

## 快速链接

- ### [Papermod - 功能](../papermod-features)

- ### [Papermod - 常见问题](../papermod-how-to)

- ### [Papermod - 变量](../papermod-variables)

- ### [Papermod - 图标](../papermod-icons)

- ### [更新日志](https://github.com/adityatelange/hugo-PaperMod/releases)

---

## 示例 `config.yml`

> **示例站点结构在这里**：[exampleSite](https://github.com/adityatelange/hugo-PaperMod/tree/exampleSite/)

**适当使用**

```yml
baseURL: "https://examplesite.com/"
title: ExampleSite
paginate: 5
theme: PaperMod

enableRobotsTXT: true
buildDrafts: false
buildFuture: false
buildExpired: false

googleAnalytics: UA-123-45

minify:
  disableXML: true
  minifyOutput: true

params:
  env: production # 启用 google analytics, opengraph, twitter-cards 和 schema.
  title: ExampleSite
  description: "ExampleSite description"
  keywords: [Blog, Portfolio, PaperMod]
  author: Me
  # author: ["Me", "You"] # 多个作者
  images: ["<link or path of image for opengraph, twitter-cards>"]
  DateFormat: "January 2, 2006"
  defaultTheme: auto # dark, light
  disableThemeToggle: false

  ShowReadingTime: true
  ShowShareButtons: true
  ShowPostNavLinks: true
  ShowBreadCrumbs: true
  ShowCodeCopyButtons: false
  ShowWordCount: true
  ShowRssButtonInSectionTermList: true
  UseHugoToc: true
  disableSpecial1stPost: false
  disableScrollToTop: false
  comments: false
  hidemeta: false
  hideSummary: false
  showtoc: false
  tocopen: false

  assets:
    # disableHLJS: true # 禁用 highlight.js
    # disableFingerprinting: true
    favicon: "<link / abs url>"
    favicon16x16: "<link / abs url>"
    favicon32x32: "<link / abs url>"
    apple_touch_icon: "<link / abs url>"
    safari_pinned_tab: "<link / abs url>"

  label:
    text: "Home"
    icon: /apple-touch-icon.png
    iconHeight: 35

  # profile-mode
  profileMode:
    enabled: false # 需要明确设置
    title: ExampleSite
    subtitle: "This is subtitle"
    imageUrl: "<img location>"
    imageWidth: 120
    imageHeight: 120
    imageTitle: my image
    buttons:
      - name: Posts
        url: posts
      - name: Tags
        url: tags

  # home-info mode
  homeInfoParams:
    Title: "Hi there \U0001F44B"
    Content: Welcome to my blog

  socialIcons:
    - name: x
      url: "https://x.com/"
    - name: stackoverflow
      url: "https://stackoverflow.com"
    - name: github
      url: "https://github.com/"

  analytics:
    google:
      SiteVerificationTag: "XYZabc"
    bing:
      SiteVerificationTag: "XYZabc"
    yandex:
      SiteVerificationTag: "XYZabc"

  cover:
    hidden: true # 隐藏但不包括在结构化数据中
    hiddenInList: true # 在列表页和首页隐藏
    hiddenInSingle: true # 在单页隐藏

  editPost:
    URL: "https://github.com/<path_to_repo>/content"
    Text: "Suggest Changes" # 编辑文本
    appendFilePath: true # 将文件路径附加到编辑链接

  # 搜索配置
  # https://fusejs.io/api/options.html
  fuseOpts:
    isCaseSensitive: false
    shouldSort: true
    location: 0
    distance: 1000
    threshold: 0.4
    minMatchCharLength: 0
    limit: 10 # 参考: https://www.fusejs.io/api/methods.html#search
    keys: ["title", "permalink", "summary", "content"]
menu:
  main:
    - identifier: categories
      name: categories
      url: /categories/
      weight: 10
    - identifier: tags
      name: tags
      url: /tags/
      weight: 20
    - identifier: example
      name: example.org
      url: https://example.org
      weight: 30
# 阅读: https://github.com/adityatelange/hugo-PaperMod/wiki/FAQs#using-hugos-syntax-highlighter-chroma
pygmentsUseClasses: true
markup:
  highlight:
    noClasses: false
    # anchorLineNos: true
    # codeFences: true
    # guessSyntax: true
    # lineNos: true
    # style: monokai
```

---

## 示例 `Page.md`

```yml
---
title: "我的第一篇文章"
date: 2020-09-15T11:30:03+00:00
# weight: 1
# aliases: ["/first"]
tags: ["first"]
author: "Me"
# author: ["Me", "You"] # 多个作者
showToc: true
TocOpen: false
draft: false
hidemeta: false
comments: false
description: "描述文本。"
canonicalURL: "https://canonical.url/to/page"
disableHLJS: true # 禁用 highlightjs
disableShare: false
disableHLJS: false
hideSummary: false
searchHidden: true
ShowReadingTime: true
ShowBreadCrumbs: true
ShowPostNavLinks: true
ShowWordCount: true
ShowRssButtonInSectionTermList: true
UseHugoToc: true
cover:
    image: "<image path/url>" # 图片路径/URL
    alt: "<alt text>" # 替代文本
    caption: "<text>" # 在封面下显示的文本
    relative: false # 使用页面 bundles 时设置为 true
    hidden: true # 仅在当前单页隐藏
editPost:
    URL: "https://github.com/<path_to_repo>/content"
    Text: "建议更改" # 编辑文本
    appendFilePath: true # 将文件路径附加到编辑链接
---
```

你可以通过创建 `archetypes/post.md` 来使用它：

```shell
hugo new --kind post <name>
```

---