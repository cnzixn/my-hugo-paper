local input_file = "易宁修改.txt"
local output_dir = "./yn"

-- 创建输出目录
os.execute("mkdir -p " .. output_dir)

-- 初始化变量
local current_paragraph = {}
local empty_paragraph = {}
local empty_line_count = 0
local file_counter = 0

-- 文件名处理函数
local function sanitize(name)
     return (name:gsub("[\\/%*%?<>:%|%\"]", "-")  -- 替换非法字符
           :gsub("^%s+", "")                     -- 去除首部空格
           :gsub("^[一二三四五六七八九十０]+\.", "")
           :gsub("%s+$", "")                     -- 去除尾部空格
           )
end

-- 处理段落函数
local function save_paragraph()
    if #current_paragraph == 0 then return end

    -- 提取文件名（首行）
    local first_line = current_paragraph[1]
    local filename = sanitize(first_line)
    -- print("filename", filename)
    -- filename = ""
    if filename == "" then
        filename = "未命名段落-" .. file_counter
    end
    local formatted_number = string.format("%03d", file_counter)

    -- 生成文件路径
    local path = output_dir .. "/YN" .. formatted_number .. "-" .. filename .. ".md"
    print("/posts/YN" .. formatted_number .. "-" .. filename .. ".md")
    
    -- 处理重复文件
    local counter = 1
    while os.rename(path, path) do
        path = output_dir .. "/YN" .. formatted_number .. "-" .. filename .. "-" .. counter .. ".md"
        counter = counter + 1
    end

    -- 写入内容（排除首行）
    local frontmate = "---"
.. "\ntitle: 'YN" .. formatted_number .. "-" .. filename .. "'"
.. "\ndate: '".. os.date("%Y-%m-%d") -- %H:%M:%S
.. "'\nauthor: Bny"
.. "\ntags:"
.. "\n  - 易宁"
.. "\naliases:"
.. "\n  - YN" .. formatted_number
.. "\ncomments: false"
.. "\n---"
.. "\n\n> 代码来源于“易宁”大佬的分享，仅供学习，不要直接复制粘贴。"
.. "\n\n原帖链接：[http://bbs.3dmgame.com/thread-3859071-1-1.html](http://bbs.3dmgame.com/thread-3859071-1-1.html)"



    local content = frontmate .. "\n\n---\n\n```lua  \n\n" .. table.concat(current_paragraph, "") .. "\n\n```  \n\n"
    local f = io.open(path, "w")
    if f then
        f:write(content)
        f:close()
    else
        print("写入失败: " .. path)
    end

    -- 重置状态
    current_paragraph = {}
    empty_line_count = 0

    file_counter = file_counter + 1
end

-- 逐行读取文件
local f = io.open(input_file, "r")
if not f then
    error("无法打开文件: " .. input_file)
end


for line in f:lines() do
    -- 检测空行
    
    if line:match("^%s*$") then  -- 匹配任何空白行
        empty_line_count = empty_line_count + 1
        if empty_line_count == 4 then
            save_paragraph()
        end
        table.insert(empty_paragraph, line)
    else
        -- 如果之前有空行但不足4个，保留空行作为内容
        if empty_line_count > 0 and empty_line_count < 4 then
            for k = 1, #empty_paragraph do
                table.insert(current_paragraph, empty_paragraph[k])
            end
        end
        empty_paragraph={}
        empty_line_count = 0
        table.insert(current_paragraph, line)
    end
end

-- 处理最后一个段落
save_paragraph()

f:close()
print("处理完成！输出目录: " .. output_dir)