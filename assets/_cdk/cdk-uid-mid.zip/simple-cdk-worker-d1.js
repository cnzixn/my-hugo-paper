export default {
  // 处理HTTP请求
  async fetch(request, env) {
    // 初始化D1数据库
    console.log('Fetch request: Starting database initialization');
    await initDB(env);
    console.log('Fetch request: Database initialization completed');
    
    // 定义 CORS headers
    const corsHeaders = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    };
    
    // 处理 OPTIONS 请求（预检请求）
    if (request.method === 'OPTIONS') {
      return new Response(null, {
        status: 204,
        headers: corsHeaders
      });
    }
    
    try {
      const url = new URL(request.url);
      const path = url.pathname;
      
      // 游戏端验证API - GET请求
      if (path === '/api/verify' && request.method === 'GET') {
        return await handleVerify(request, env, corsHeaders);
      }
      
      // Android公告API - GET请求，返回notice-{timestamp}.json文件
      if (path === '/api/notice' && request.method === 'GET') {
        return await handleAnnouncement(request, env, corsHeaders);
      }
      
      // 搜索CDK API - GET请求，返回所有匹配的CDK
      if (path === '/api/search' && request.method === 'GET') {
        return await handleSearch(request, env, corsHeaders);
      }
      
      // 管理端API
      if (path.startsWith('/api/admin/')) {
        return await handleAdminRoutes(request, env, corsHeaders, path);
      }
      
      // 获取单个CDK详情API - GET请求
      if (path.startsWith('/api/cdk/') && request.method === 'GET') {
        return await handleGetCDKDetail(request, env, corsHeaders);
      }
      
      // 404 未找到的路由
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Not found',
        path: path
      }), {
        status: 404,
        headers: corsHeaders
      });
      
    } catch (error) {
      console.error('Worker error:', error);
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Internal server error',
        message: error.message
      }), {
        status: 500,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        }
      });
    }
  },
  
  // 处理定时任务（Cloudflare Workers Cron Triggers）
  async scheduled(event, env, ctx) {
    console.log('Running scheduled cleanup task...');
    try {
      // 初始化D1数据库
      await initDB(env);
      const cleanedCount = await cleanupCDKs(env);
      console.log(`Scheduled cleanup completed, ${cleanedCount} CDKs removed`);
      return cleanedCount;
    } catch (error) {
      console.error('Scheduled cleanup error:', error);
      return 0;
    }
  }
};

// 初始化D1表（首次运行时调用）
async function initDB(env) {
  console.log('initDB: Starting initialization');
  
  try {
    // 检查数据库绑定是否存在
    if (!env.CDK_DB) {
      console.error('initDB: CDK_DB binding not found');
      return;
    }
    
    console.log('initDB: Executing CREATE TABLE statement');
    
    // 创建CDK表 - 使用更简单的方式执行
    const createTableResult = await env.CDK_DB.prepare(`
      CREATE TABLE IF NOT EXISTS cdks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE NOT NULL,
        uid TEXT, -- 用户账号，一个账号可以有多个CDK
        mid TEXT, -- 设备码，一个CDK只能绑定一个设备
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        used INTEGER NOT NULL DEFAULT 0,
        bound_at TEXT,
        days INTEGER NOT NULL DEFAULT 30,
        expire_at TEXT
      )
    `).run();
    
    console.log('initDB: CREATE TABLE result:', createTableResult);
    
    // 表结构迁移：检查并添加mid列（SQLite兼容方式）
    try {
      // 检查mid列是否存在
      const checkColumnResult = await env.CDK_DB.prepare(`
        PRAGMA table_info(cdks)
      `).all();
      
      const hasMidColumn = checkColumnResult.results.some(column => column.name === 'mid');
      
      if (!hasMidColumn) {
        // mid列不存在，添加该列
        await env.CDK_DB.prepare(`
          ALTER TABLE cdks ADD COLUMN mid TEXT
        `).run();
        console.log('initDB: mid column added successfully');
      } else {
        console.log('initDB: mid column already exists');
      }
    } catch (error) {
      console.error('initDB: Failed to check or add mid column:', error);
    }
    
    // 创建索引
    console.log('initDB: Creating indexes');
    
    const indexes = [
      'CREATE INDEX IF NOT EXISTS idx_cdks_code ON cdks(code)',
      'CREATE INDEX IF NOT EXISTS idx_cdks_used ON cdks(used)',
      'CREATE INDEX IF NOT EXISTS idx_cdks_expire_at ON cdks(expire_at)',
      'CREATE INDEX IF NOT EXISTS idx_cdks_mid ON cdks(mid)',
      'CREATE INDEX IF NOT EXISTS idx_cdks_uid ON cdks(uid)'
    ];
    
    for (const indexSQL of indexes) {
      try {
        const indexResult = await env.CDK_DB.prepare(indexSQL).run();
        console.log('initDB: CREATE INDEX result for', indexSQL, ':', indexResult);
      } catch (error) {
        console.error('initDB: Failed to create index', indexSQL, ':', error);
      }
    }
    
    // 验证表是否创建成功
    console.log('initDB: Verifying table exists');
    const tablesResult = await env.CDK_DB.prepare(
      "SELECT name FROM sqlite_master WHERE type='table' AND name='cdks'"
    ).first();
    
    console.log('initDB: Table verification result:', tablesResult);
    
    if (tablesResult) {
      console.log('initDB: D1 database initialized successfully, table exists');
    } else {
      console.error('initDB: Table cdks was not created successfully');
    }
    
  } catch (error) {
    console.error('initDB: Failed to initialize D1 database:', error);
    console.error('initDB: Error details:', {
      message: error.message,
      stack: error.stack,
      name: error.name
    });
    // 不抛出异常，继续处理请求
  }
}

// 处理管理端路由
async function handleAdminRoutes(request, env, corsHeaders, path) {
  // 从环境变量获取管理员账号、密码和salt
  const adminUsername = env.ADMIN_USERNAME || 'admin';
  const adminPassword = env.ADMIN_PASSWORD || 'admin123'; // 请确保在环境变量中设置
  const adminSalt = env.ADMIN_SALT || 'default_salt';
  
  // 验证认证信息
  const authHeader = request.headers.get('Authorization') || '';
  
  if (!authHeader.startsWith('Hash ')) {
    return new Response(JSON.stringify({ 
      success: false, 
      error: 'Authorization header missing or invalid' 
    }), { 
      status: 401,
      headers: corsHeaders
    });
  }
  
  const token = authHeader.substring(5);
  const parts = token.split(':');
  
  if (parts.length !== 2) {
    return new Response(JSON.stringify({ 
      success: false, 
      error: 'Invalid authorization format' 
    }), { 
      status: 401,
      headers: corsHeaders
    });
  }
  
  const username = parts[0];
  const passwordHash = parts[1];
  
  // 计算环境变量中密码的哈希
  const expectedHash = await hashCredentials(adminUsername, adminPassword, adminSalt);
  
  if (username !== adminUsername || passwordHash !== expectedHash) {
    return new Response(JSON.stringify({ 
      success: false, 
      error: 'Unauthorized' 
    }), { 
      status: 401,
      headers: corsHeaders
    });
  }
  
  // 认证成功，处理具体的管理端API
    if (path === '/api/admin/generate' && request.method === 'POST') {
      return await handleAdminGenerate(request, env, corsHeaders);
    }
    
    if (path === '/api/admin/list' && request.method === 'GET') {
      return await handleAdminList(request, env, corsHeaders);
    }
    
    if (path === '/api/admin/delete' && request.method === 'POST') {
      return await handleAdminDelete(request, env, corsHeaders);
    }
    
    if (path === '/api/admin/delete-unused' && request.method === 'POST') {
      return await handleAdminDeleteUnused(request, env, corsHeaders);
    }
    
    // 导出CDK为TXT文件
    if (path === '/api/admin/export' && request.method === 'GET') {
      return await handleAdminExportCDK(request, env, corsHeaders);
    }
    
    // 清除CDK绑定的UID - POST请求
    if (path === '/api/admin/clear-uid' && request.method === 'POST') {
      return await handleAdminClearUID(request, env, corsHeaders);
    }
    
    // 管理端404
    return new Response(JSON.stringify({ 
      success: false, 
      error: 'Admin API not found' 
    }), { 
      status: 404,
      headers: corsHeaders
    });
}

// 游戏端验证API - 支持返回JSON或token.txt文件
async function handleVerify(request, env, corsHeaders) {
  // 提前解析URL和请求参数，避免在catch块中重复解析
  let url, uid, cdkCode, mid, timestamp, isAndroidRequest, isiOSRequest;
  try {
    url = new URL(request.url);
    uid = url.searchParams.get('uid'); // 用户账号（必填）
    cdkCode = url.searchParams.get('cdk'); // CDK兑换码（必填）
    mid = url.searchParams.get('mid'); // 设备码（必填）
    timestamp = url.searchParams.get('time') || url.searchParams.get('timestamp') || Math.floor(Date.now() / 1000);
    
    // 确保timestamp是字符串且只包含数字
    timestamp = String(timestamp).replace(/[^0-9]/g, '');
    
    // 检查是否是Android请求（根据参数判断）
    // 支持多种参数名：android, format=txt, responseType=file, type=android
    isAndroidRequest = 
      url.searchParams.get('android') !== null ||
      url.searchParams.get('format') === 'txt' ||
      url.searchParams.get('responseType') === 'file' ||
      url.searchParams.get('type') === 'android';
    
    // 检查是否是iOS请求（根据参数判断）
    // 支持参数名：ios, type=ios
    isiOSRequest = 
      url.searchParams.get('ios') !== null ||
      url.searchParams.get('type') === 'ios';
    
  } catch (parseError) {
    console.error('URL parsing error:', parseError);
    // 返回通用错误 - JSON响应
    return new Response(JSON.stringify({ 
      success: false, 
      error: 'Invalid URL format' 
    }), { 
      status: 400,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
  
  try {
    // 1. 验证请求参数
    if (!uid || !cdkCode || !mid) {
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Missing uid, cdk or mid parameter' 
      }), { 
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    
    // 2. 查询CDK
    const cdkResult = await env.CDK_DB.prepare(`
      SELECT * FROM cdks WHERE code = ?
    `).bind(cdkCode).first();
  
    // 3. 检查CDK是否存在
    if (!cdkResult) {
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Invalid CDK' 
      }), { 
        status: 404,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    
    const now = new Date();
    let expireDate;
    
    // 4. 检查CDK是否已使用
    if (cdkResult.used) {
      // 4.1 检查是否属于当前UID
      if (cdkResult.uid !== uid) {
        // CDK已被其他用户使用 - 返回错误
        return new Response(JSON.stringify({ 
          success: false, 
          error: 'CDK already used by another user' 
        }), { 
          status: 403,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json'
          }
        });
      }
      
      // 4.2 属于当前用户，允许换绑MID
      // 更新CDK的设备码和绑定时间
      await env.CDK_DB.prepare(`
        UPDATE cdks SET 
          mid = ?, 
          bound_at = ?
        WHERE code = ?
      `).bind(mid, now.toISOString(), cdkCode).run();
      
      // 使用已有的过期时间
      expireDate = new Date(cdkResult.expire_at);
    } else {
      // 5. CDK未使用 - 绑定到当前用户和设备
      // 计算过期时间
      expireDate = new Date(now.getTime() + (parseInt(cdkResult.days) * 24 * 60 * 60 * 1000));
      
      // 绑定CDK到当前UID和MID
      await env.CDK_DB.prepare(`
        UPDATE cdks SET 
          used = 1, 
          uid = ?, 
          mid = ?, 
          bound_at = ?, 
          expire_at = ?
        WHERE code = ?
      `).bind(uid, mid, now.toISOString(), expireDate.toISOString(), cdkCode).run();
    }
    
    // 生成验证令牌，根据请求类型设置不同的有效期
    let tokenExpireAt;
    if (isiOSRequest) {
      // iOS请求：token有效期7天
      const sevenDaysLater = new Date();
      sevenDaysLater.setDate(sevenDaysLater.getDate() + 7);
      tokenExpireAt = sevenDaysLater.toISOString();
    } else {
      // 安卓或其他请求：继续使用CDK的过期时间
      tokenExpireAt = expireDate.toISOString();
    }
    
    const verifyToken = await generateVerifyToken(uid, cdkCode, mid, env.VERIFY_SECRET || 'default_secret', tokenExpireAt);
    
    if (isAndroidRequest) {
      // 只有成功时，Android请求才返回文件
      const fileName = `token-${timestamp}.txt`;
      const responseHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'text/plain',
        'Content-Disposition': `attachment; filename=${fileName}`
      };
      return new Response(verifyToken, {
        status: 200,
        headers: responseHeaders
      });
    } else {
      // 普通请求或iOS请求：返回JSON成功
      return new Response(JSON.stringify({ 
        success: true, 
        message: 'CDK activated successfully',
        token: verifyToken
      }), { 
        status: 200,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    
  } catch (error) {
    console.error('Verify error:', error);
    const errorMessage = error.message && error.message.includes('no such table') 
      ? 'Database table does not exist' 
      : 'Internal server error';
    
    // 所有错误情况都返回JSON响应
    return new Response(JSON.stringify({ 
      success: false, 
      error: errorMessage
    }), { 
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
}

// Android公告API - 返回notice-{timestamp}.json文件
async function handleAnnouncement(request, env, corsHeaders) {
  try {
    const url = new URL(request.url);
    // 获取时间戳参数，用于命名文件
    let timestamp = url.searchParams.get('time') || url.searchParams.get('timestamp') || Date.now().toString();
    
    // 确保timestamp是字符串且只包含数字
    timestamp = String(timestamp).replace(/[^0-9]/g, '');
    
    // 公告源URL
    const announcementUrl = 'https://d.bxq.me/files/announcement-shipwrecked.json';
    
    try {
      // 从源URL获取公告内容
      const response = await fetch(announcementUrl);
      
      if (!response.ok) {
        throw new Error(`Failed to fetch announcement: ${response.statusText}`);
      }
      
      // 获取公告内容
      const announcementContent = await response.text();
      
      // 设置响应头，返回notice-{timestamp}.json文件
      const fileName = `notice-${timestamp}.json`;
      const responseHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json',
        'Content-Disposition': `attachment; filename=${fileName}`
      };
      
      // 返回公告内容作为文件
      return new Response(announcementContent, {
        status: 200,
        headers: responseHeaders
      });
      
    } catch (error) {
      console.error('Failed to fetch announcement:', error);
      
      // 返回错误信息到notice-{timestamp}.json文件
      const errorContent = JSON.stringify({
        error: 'Failed to fetch announcement',
        message: error.message || 'Unknown error'
      });
      
      const fileName = `notice-${timestamp}.json`;
      const errorHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json',
        'Content-Disposition': `attachment; filename=${fileName}`
      };
      
      return new Response(errorContent, {
        status: 500,
        headers: errorHeaders
      });
    }
    
  } catch (error) {
    console.error('Announcement API error:', error);
    
    // 获取时间戳，用于命名错误文件
    const timestamp = Date.now().toString().replace(/[^0-9]/g, '');
    
    // 返回错误信息到notice-{timestamp}.json文件
    const errorContent = JSON.stringify({
      error: 'Internal server error',
      message: error.message || 'Unknown error'
    });
    
    const fileName = `notice-${timestamp}.json`;
    const errorHeaders = {
      'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json',
      'Content-Disposition': `attachment; filename=${fileName}`
    };
    
    return new Response(errorContent, {
      status: 500,
      headers: errorHeaders
    });
  }
}

// 搜索CDK API - 返回所有匹配的CDK
async function handleSearch(request, env, corsHeaders) {
  try {
    const url = new URL(request.url);
    let searchTerm = url.searchParams.get('q') || '';
    
    // 过滤搜索词中的连字符，确保与数据库中存储的格式匹配
    searchTerm = searchTerm.replace(/-/g, '');
    
    if (!searchTerm.trim()) {
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Search term is required' 
      }), { 
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    
    // 先检查cdks表是否存在
    const tableExists = await env.CDK_DB.prepare(
      "SELECT name FROM sqlite_master WHERE type='table' AND name='cdks'"
    ).first();
    
    if (!tableExists) {
      return new Response(JSON.stringify({
        success: false,
        error: 'Database table does not exist. Please check if the database is properly initialized.'
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    
    // 执行搜索查询，先检查mid列是否存在，然后动态构建查询
    let searchResult;
    try {
      // 检查mid列是否存在
      const checkColumnResult = await env.CDK_DB.prepare(`
        PRAGMA table_info(cdks)
      `).all();
      
      const hasMidColumn = checkColumnResult.results.some(column => column.name === 'mid');
      
      let searchQuery;
      let searchParams;
      
      if (hasMidColumn) {
        // mid列存在，搜索code、uid和mid
        searchQuery = `
          SELECT * FROM cdks 
          WHERE code LIKE ? OR uid LIKE ? OR mid LIKE ?
          ORDER BY created_at DESC
        `;
        searchParams = [`%${searchTerm}%`, `%${searchTerm}%`, `%${searchTerm}%`];
      } else {
        // mid列不存在，只搜索code和uid
        searchQuery = `
          SELECT * FROM cdks 
          WHERE code LIKE ? OR uid LIKE ?
          ORDER BY created_at DESC
        `;
        searchParams = [`%${searchTerm}%`, `%${searchTerm}%`];
      }
      
      searchResult = await env.CDK_DB.prepare(searchQuery)
        .bind(...searchParams)
        .all();
    } catch (error) {
      console.error('Search query error:', error);
      return new Response(JSON.stringify({ 
        success: false, 
        error: `Search query failed: ${error.message}` 
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    
    // 转换结果格式，在返回前添加连字符格式
    const cdks = searchResult.results.map(cdk => ({
      code: cdk.code.replace(/(.{4})(?=.)/g, '$1-'),
      uid: cdk.uid || '',
      mid: cdk.mid || '',
      createdAt: cdk.created_at,
      used: cdk.used === 1,
      boundAt: cdk.bound_at || null,
      days: cdk.days,
      expireAt: cdk.expire_at || null
    }));
    
    return new Response(JSON.stringify({
      success: true,
      cdks: cdks,
      total: cdks.length,
      searchTerm: searchTerm.replace(/(.{4})(?=.)/g, '$1-')
    }), {
      status: 200,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  } catch (error) {
    console.error('Search error:', error);
    return new Response(JSON.stringify({ 
      success: false, 
      error: `Internal server error: ${error.message}` 
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
}



// 生成CDK
async function handleAdminGenerate(request, env, corsHeaders) {
  try {
    // 检查是否为POST请求
    if (request.method !== 'POST') {
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Method not allowed' 
      }), { 
        status: 405,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    
    let count = 10;
    let days = 30; // 默认30天
    try {
      const body = await request.json();
      count = body.count || 10;
      days = body.days || 30;
    } catch (e) {
      // 使用默认值
    }
    
    if (count < 1 || count > 1000) {
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Count must be between 1 and 1000' 
      }), { 
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    
    const cdks = [];
    const now = new Date().toISOString();
    
    try {
      // 生成CDK
      for (let i = 0; i < count; i++) {
        const code = generateRandomString(16);
        
        // 插入CDK到D1
        await env.CDK_DB.prepare(`
          INSERT INTO cdks (code, days, created_at) VALUES (?, ?, ?)
        `).bind(code, days, now).run();
      
      cdks.push({
        code: code.replace(/(.{4})(?=.)/g, '$1-'),
        uid: null,
        createdAt: now,
        used: false,
        boundAt: null,
        days: days,
        expireAt: null
      });
    }
    
    return new Response(JSON.stringify({
      success: true,
      cdks: cdks,
      count: cdks.length,
      message: 'CDKs generated successfully'
    }), {
      status: 200,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
    
    } catch (error) {
      console.error('Generate CDK error:', error);
      if (error.message && error.message.includes('no such table')) {
        return new Response(JSON.stringify({ 
          success: false, 
          error: 'Database table does not exist. Please contact administrator.' 
        }), {
          status: 500,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json'
          }
        });
      }
      return new Response(JSON.stringify({ 
        success: false, 
        error: `Internal server error: ${error.message}` 
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
  } catch (error) {
    console.error('Generate CDK error:', error);
    return new Response(JSON.stringify({ 
      success: false, 
      error: `Internal server error: ${error.message}` 
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
}

// 查询CDK列表
async function handleAdminList(request, env, corsHeaders) {
  try {
    // 获取分页参数
    const url = new URL(request.url);
    const page = parseInt(url.searchParams.get('page') || '1');
    const pageSize = parseInt(url.searchParams.get('pageSize') || '100');
    
    // 先检查cdks表是否存在
    console.log('handleAdminList: Checking if table exists');
    const tableExists = await env.CDK_DB.prepare(
      "SELECT name FROM sqlite_master WHERE type='table' AND name='cdks'"
    ).first();
    
    if (!tableExists) {
      console.error('handleAdminList: Table cdks does not exist');
      return new Response(JSON.stringify({
        success: false,
        error: 'Database table does not exist. Please check if the database is properly initialized.'
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    
    console.log('handleAdminList: Table exists, proceeding with query');
    
    // 查询总数
    const countResult = await env.CDK_DB.prepare(`
      SELECT COUNT(*) as total FROM cdks
    `).first();
    const total = countResult.total;
    const totalPages = Math.ceil(total / pageSize);
    
    // 查询CDK列表
    const offset = (page - 1) * pageSize;
    const cdksResult = await env.CDK_DB.prepare(`
      SELECT * FROM cdks ORDER BY created_at DESC LIMIT ? OFFSET ?
    `).bind(pageSize, offset).all();
    
    // 格式化结果，添加连字符格式
    const cdks = cdksResult.results.map(cdk => ({
      code: cdk.code.replace(/(.{4})(?=.)/g, '$1-'),
      uid: cdk.uid || '',
      mid: cdk.mid || '',
      createdAt: cdk.created_at,
      used: Boolean(cdk.used),
      boundAt: cdk.bound_at || null,
      days: cdk.days,
      expireAt: cdk.expire_at || null
    }));
    
    return new Response(JSON.stringify({
      success: true,
      cdks: cdks,
      total: total,
      page: page,
      pageSize: pageSize,
      totalPages: totalPages
    }), {
      status: 200,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
    
  } catch (error) {
    console.error('List CDK error:', error);
    return new Response(JSON.stringify({ 
      success: false, 
      error: `Internal server error: ${error.message}` 
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
}

// 删除CDK
async function handleAdminDelete(request, env, corsHeaders) {
  try {
    // 检查是否为POST请求
    if (request.method !== 'POST') {
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Method not allowed' 
      }), { 
        status: 405,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    
    const body = await request.json();
    // 移除CDK中的连字符，以便匹配数据库中的存储格式
    const cdkCode = body.cdk.replace(/-/g, '');
    
    if (!cdkCode) {
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Missing cdk parameter' 
      }), { 
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    
    try {
      // 删除CDK
      const deleteResult = await env.CDK_DB.prepare(`
        DELETE FROM cdks WHERE code = ?
      `).bind(cdkCode).run();
    
    if (deleteResult.changes === 0) {
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'CDK not found' 
      }), { 
        status: 404,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    
    return new Response(JSON.stringify({
      success: true,
      message: 'CDK deleted successfully'
    }), {
      status: 200,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
    
    } catch (error) {
      console.error('Delete CDK error:', error);
      if (error.message && error.message.includes('no such table')) {
        return new Response(JSON.stringify({ 
          success: false, 
          error: 'Database table does not exist. Please contact administrator.' 
        }), {
          status: 500,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json'
          }
        });
      }
      return new Response(JSON.stringify({ 
        success: false, 
        error: `Internal server error: ${error.message}` 
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
  } catch (error) {
    console.error('Delete CDK error:', error);
    return new Response(JSON.stringify({ 
      success: false, 
      error: `Internal server error: ${error.message}` 
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
}

// 删除所有未使用的CDK
async function handleAdminDeleteUnused(request, env, corsHeaders) {
  try {
    // 检查是否为POST请求
    if (request.method !== 'POST') {
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Method not allowed' 
      }), { 
        status: 405,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    
    try {
      // 删除所有未使用的CDK
      const deleteResult = await env.CDK_DB.prepare(`
        DELETE FROM cdks WHERE used = 0
      `).run();
    
    return new Response(JSON.stringify({
      success: true,
      message: 'Unused CDKs deleted successfully',
      count: deleteResult.changes
    }), {
      status: 200,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
    
    } catch (error) {
      console.error('Delete unused CDKs error:', error);
      if (error.message && error.message.includes('no such table')) {
        return new Response(JSON.stringify({ 
          success: false, 
          error: 'Database table does not exist. Please contact administrator.' 
        }), {
          status: 500,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json'
          }
        });
      }
      return new Response(JSON.stringify({ 
        success: false, 
        error: `Internal server error: ${error.message}` 
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
  } catch (error) {
    console.error('Delete unused CDKs error:', error);
    return new Response(JSON.stringify({ 
      success: false, 
      error: `Internal server error: ${error.message}` 
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
}

// 清除CDK绑定的UID - 恢复为未使用状态
async function handleAdminClearUID(request, env, corsHeaders) {
  try {
    // 检查是否为POST请求
    if (request.method !== 'POST') {
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Method not allowed' 
      }), { 
        status: 405,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    
    const body = await request.json();
    const cdkCode = body.cdk;
    
    if (!cdkCode) {
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Missing cdk parameter' 
      }), { 
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    
    try {
      // 移除CDK中的连字符，以便匹配数据库中的存储格式
      const cleanCdkCode = cdkCode.replace(/-/g, '');
      
      // 检查CDK是否存在
      const cdkResult = await env.CDK_DB.prepare(`
        SELECT * FROM cdks WHERE code = ?
      `).bind(cleanCdkCode).first();
      
      if (!cdkResult) {
        return new Response(JSON.stringify({ 
          success: false, 
          error: 'CDK not found' 
        }), { 
          status: 404,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json'
          }
        });
      }
      
      // 更新CDK状态，只清除mid和绑定时间，保持used状态和uid不变
      // 这样CDK一旦被使用就不能被其他用户使用
      const updateResult = await env.CDK_DB.prepare(`
        UPDATE cdks SET 
          mid = NULL, 
          bound_at = NULL
        WHERE code = ?
      `).bind(cleanCdkCode).run();
      
      if (updateResult.changes === 0) {
        return new Response(JSON.stringify({ 
          success: false, 
          error: 'Failed to clear UID' 
        }), { 
          status: 500,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json'
          }
        });
      }
      
      return new Response(JSON.stringify({
        success: true,
        message: 'CDK UID cleared successfully',
        cdk: cleanCdkCode
      }), {
        status: 200,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
      
    } catch (error) {
      console.error('Clear UID error:', error);
      if (error.message && error.message.includes('no such table')) {
        return new Response(JSON.stringify({ 
          success: false, 
          error: 'Database table does not exist. Please contact administrator.' 
        }), {
          status: 500,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json'
          }
        });
      }
      return new Response(JSON.stringify({ 
        success: false, 
        error: `Internal server error: ${error.message}` 
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
  } catch (error) {
    console.error('Clear UID error:', error);
    return new Response(JSON.stringify({ 
      success: false, 
      error: `Internal server error: ${error.message}` 
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
}

// 导出CDK为TXT文件
async function handleAdminExportCDK(request, env, corsHeaders) {
  try {
    // 先检查cdks表是否存在
    const tableExists = await env.CDK_DB.prepare(
      "SELECT name FROM sqlite_master WHERE type='table' AND name='cdks'"
    ).first();
    
    if (!tableExists) {
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Database table does not exist. Please contact administrator.' 
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    
    // 查询所有CDK，包含使用状态和天数
    const cdksResult = await env.CDK_DB.prepare(`
      SELECT * FROM cdks ORDER BY used DESC, days ASC, created_at DESC
    `).all();
    
    // 分离已使用和未使用的CDK
    const usedCDKs = cdksResult.results.filter(cdk => cdk.used === 1);
    const unusedCDKs = cdksResult.results.filter(cdk => cdk.used === 0);
    
    // 对未使用的CDK按天数分类
    const unusedCDKsByDays = {};
    for (const cdk of unusedCDKs) {
      const days = cdk.days;
      if (!unusedCDKsByDays[days]) {
        unusedCDKsByDays[days] = [];
      }
      unusedCDKsByDays[days].push(cdk);
    }
    
    // 格式化CDK文本，已使用和未使用分开
    let cdkText = `=== CDK导出结果 ===\n`;
    cdkText += `导出时间: ${new Date().toISOString()}\n`;
    cdkText += `总计: ${cdksResult.results.length} 个\n`;
    cdkText += `已使用: ${usedCDKs.length} 个\n`;
    cdkText += `未使用: ${unusedCDKs.length} 个\n\n`;
    
    if (usedCDKs.length > 0) {
      cdkText += `=== 已使用CDK (${usedCDKs.length}个) ===\n`;
      for (const cdk of usedCDKs) {
        // 每4字符插入-，先过滤已有-避免重复
        const formattedCode = cdk.code.replace(/-/g, '').replace(/(.{4})(?=.)/g, '$1-');
        cdkText += `${formattedCode}\n`;
      }
      cdkText += '\n';
    }
    
    if (unusedCDKs.length > 0) {
      cdkText += `=== 未使用CDK (${unusedCDKs.length}个) ===\n`;
      
      // 按天数分类显示未使用的CDK
      const daysList = Object.keys(unusedCDKsByDays).sort((a, b) => parseInt(a) - parseInt(b));
      for (const days of daysList) {
        const cdksInGroup = unusedCDKsByDays[days];
        cdkText += `\n--- ${days}天 (${cdksInGroup.length}个) ---\n`;
        for (const cdk of cdksInGroup) {
          // 每4字符插入-，先过滤已有-避免重复
          const formattedCode = cdk.code.replace(/-/g, '').replace(/(.{4})(?=.)/g, '$1-');
          cdkText += `${formattedCode}\n`;
        }
      }
    }
    
    // 设置响应头，返回TXT文件
    const txtHeaders = {
      'Access-Control-Allow-Origin': '*',
      'Content-Type': 'text/plain',
      'Content-Disposition': 'attachment; filename=cdks_export.txt'
    };
    
    return new Response(cdkText, {
      status: 200,
      headers: txtHeaders
    });
    
  } catch (error) {
    console.error('Export CDK error:', error);
    return new Response(JSON.stringify({ 
      success: false, 
      error: `Internal server error: ${error.message}` 
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
}

// 获取单个CDK详情API
async function handleGetCDKDetail(request, env, corsHeaders) {
  try {
    const url = new URL(request.url);
    const pathParts = url.pathname.split('/');
    // 移除CDK中的连字符，以便匹配数据库中的存储格式
    const cdkCode = pathParts[pathParts.length - 1].replace(/-/g, '');
    
    if (!cdkCode) {
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Missing CDK code parameter' 
      }), { 
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    
    try {
      // 查询CDK详情
      const cdkResult = await env.CDK_DB.prepare(`
        SELECT * FROM cdks WHERE code = ?
      `).bind(cdkCode).first();
    
    if (!cdkResult) {
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Invalid CDK' 
      }), { 
        status: 404,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    
    // 格式化结果，添加连字符格式
    const cdk = {
      code: cdkResult.code.replace(/(.{4})(?=.)/g, '$1-'),
      uid: cdkResult.uid || '',
      mid: cdkResult.mid || '',
      createdAt: cdkResult.created_at,
      used: Boolean(cdkResult.used),
      boundAt: cdkResult.bound_at || null,
      days: cdkResult.days,
      expireAt: cdkResult.expire_at || null
    };
    
    return new Response(JSON.stringify({ 
      success: true, 
      cdk: cdk 
    }), { 
      status: 200,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
    } catch (error) {
      console.error('Get CDK detail error:', error);
      if (error.message && error.message.includes('no such table')) {
        return new Response(JSON.stringify({ 
          success: false, 
          error: 'Database table does not exist. Please contact administrator.' 
        }), { 
          status: 500,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json'
          }
        });
      }
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Internal server error' 
      }), { 
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
  } catch (error) {
    console.error('Get CDK detail error:', error);
    return new Response(JSON.stringify({ 
      success: false, 
      error: 'Internal server error' 
    }), { 
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
}

// 自动清理过期或已使用的CDK
async function cleanupCDKs(env) {
  try {
    // 先检查cdks表是否存在
    const tableExists = await env.CDK_DB.prepare(
      "SELECT name FROM sqlite_master WHERE type='table' AND name='cdks'"
    ).first();
    
    if (!tableExists) {
      console.error('cleanupCDKs: Table cdks does not exist, skipping cleanup');
      return 0;
    }
    
    const now = new Date().toISOString();
    
    // 清理已使用且已过期的CDK
    const cleanupResult1 = await env.CDK_DB.prepare(`
      DELETE FROM cdks 
      WHERE used = 1 AND (expire_at < ? OR bound_at < datetime('now', '-30 days'))
    `).bind(now).run();
    
    // 清理未使用但已过期的CDK
    const cleanupResult2 = await env.CDK_DB.prepare(`
      DELETE FROM cdks 
      WHERE used = 0 AND expire_at < ?
    `).bind(now).run();
    
    const totalCleaned = cleanupResult1.changes + cleanupResult2.changes;
    console.log(`CDK cleanup completed: ${totalCleaned} CDKs removed`);
    return totalCleaned;
  } catch (error) {
    console.error('CDK cleanup error:', error);
    return 0;
  }
}

// ================= 辅助函数 =================

// 生成验证令牌
async function generateVerifyToken(uid, cdk, mid, secret, expireAt) {
  // 使用过期时间作为时间戳，如果没有则使用当前时间
  let timestamp;
  if (expireAt) {
    timestamp = Math.floor(new Date(expireAt).getTime() / 1000);
  } else {
    timestamp = Math.floor(Date.now() / 1000);
  }
  
  // 在token中包含mid，确保token与设备绑定，防止被盗用
  const data = `${uid}:${cdk}:${mid}:${secret}:${timestamp}`;
  
  const encoder = new TextEncoder();
  const dataBuffer = encoder.encode(data);
  const hashBuffer = await crypto.subtle.digest('MD5', dataBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const token = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  
  return `${token}:${timestamp}`;
}

// 管理员认证哈希
async function hashCredentials(username, password, salt) {
  const encoder = new TextEncoder();
  const data = encoder.encode(`${username}..${password}..${salt}`);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// 生成随机字符串
function generateRandomString(length, chars = '23456789QWERTYUPASDFGHJKLZXCVBNM') {
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}
