---
title: ""
layout: page
searchHidden: true
draft: true
---

<style>
    h1 {
        text-align: center;
        margin-bottom: 30px;
    }
    .section {
        margin-bottom: 30px;
        padding: 20px;
        border: 1px solid #ddd;
        border-radius: 3px;
    }
    .drop-zone {
        border: 2px dashed #aaa;
        padding: 20px;
        text-align: center;
        margin: 10px 0;
        cursor: pointer;
        border-radius: 3px;
    }
    .drop-zone.drag-over {
        border-color: #666;
    }
    .section button {
        border: 1px solid #ccc;
        border-radius: 5px;
        padding: 10px; /* 可去掉左右固定padding，避免与width冲突 */
        margin: 10px auto;
        border-radius: 3px;
        cursor: pointer;
        display: block;
        width: 200px; /* 固定宽度，根据需求调整数值 */
    }
    .section button:hover {
        transform: translateY(-1px);
        box-shadow: 0 2px 8px #666;
    }

    .file-info {
        margin: 10px 0;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 3px;
    }
    .progress-container {
        margin: 10px 0;
        display: none;
    }
    .progress-bar {
        height: 20px;
        border-radius: 3px;
        overflow: hidden;
    }
    .progress-fill {
        height: 100%;
        width: 0%;
        transition: width 0.3s;
    }
    .error {
        color: red;
        margin: 10px 0;
        display: none;
    }
    .file-list {
        margin: 10px 0;
        max-height: 200px;
        overflow-y: auto;
        border: 1px solid #ddd;
        padding: 10px;
        background-color: #fff;
    }
    .file-item {
        padding: 5px;
        border-bottom: 1px solid #eee;
    }
    .file-item:last-child {
        border-bottom: none;
    }
</style>



<h1><i class="bi bi-apple"></i> 模组安装器</h1>

<div class="section">
    <p><strong>温馨提示：</strong> 本工具<strong>不消耗流量</strong>，文件在浏览器本地处理，不需要上传到服务器。经过测试，Chrome、Edge浏览器可正常使用本工具，其他浏览器兼容性未知。</p>
</div>

<div class="section">
    <h2>1. 选择IPA安装包</h2>
    <div id="ipaDropZone" class="drop-zone">
        <p>拖放 .ipa 文件到这里 或</p>
        <button id="ipaBrowseBtn">选择IPA文件</button>
        <input type="file" id="ipaFileInput" accept=".ipa" style="display: none;">
    </div>
    <div id="ipaFileInfo" class="file-info" style="display: none;"></div>
    <div id="ipaError" class="error"></div>
</div>

<div class="section">
    <h2>2. 选择框架文件</h2>
    <div id="frameworkDropZone" class="drop-zone">
        <p>拖放 BM框架.zip 文件到这里 或</p>
        <button id="frameworkBrowseBtn">选择框架文件</button>
        <input type="file" id="frameworkFileInput" accept=".zip" style="display: none;">
    </div>
    <div id="frameworkFileInfo" class="file-info" style="display: none;"></div>
    <div id="frameworkError" class="error"></div>
</div>

<div class="section">
    <h2>3. 选择模组文件 (多选)</h2>
    <div id="modsDropZone" class="drop-zone">
        <p>拖放 BM模组.zip 文件到这里 或</p>
        <button id="modsBrowseBtn">选择模组文件</button>
        <input type="file" id="modsFileInput" accept=".zip" multiple style="display: none;">
    </div>
    <div id="modsFileList" class="file-list" style="display: none;"></div>
    <div id="modsError" class="error"></div>
</div>

<div class="section">
    <h2>4. 安装模组</h2>
    <button id="installBtn" disabled>开始安装</button>
    <div id="installProgress" class="progress-container">
        <div class="progress-bar">
            <div id="installProgressFill" class="progress-fill"></div>
        </div>
        <p id="installProgressText">准备就绪</p>
    </div>
    <div id="installError" class="error"></div>
    <div id="installResult" style="display: none;">
        <h3>安装完成！</h3>
        <button id="downloadBtn">下载修改后的IPA</button>
    </div>
</div>


<!-- <div class="section"> -->
  <!-- <p><strong>免责声明：</strong> 本工具仅供学习使用，请勿用于任何非法用途。使用本工具即表示您了解并同意承担所有责任。</p> -->
<!-- </div> -->

<script src="/js/klfa.encrypt.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/2.0.5/FileSaver.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        // 文件变量
        let ipaFile = null;
        let frameworkFile = null;
        let modFiles = [];
        let modifiedIpa = null;
        
        // DOM元素
        const ipaDropZone = document.getElementById('ipaDropZone');
        const ipaFileInput = document.getElementById('ipaFileInput');
        const ipaBrowseBtn = document.getElementById('ipaBrowseBtn');
        const ipaFileInfo = document.getElementById('ipaFileInfo');
        const ipaError = document.getElementById('ipaError');
        
        const frameworkDropZone = document.getElementById('frameworkDropZone');
        const frameworkFileInput = document.getElementById('frameworkFileInput');
        const frameworkBrowseBtn = document.getElementById('frameworkBrowseBtn');
        const frameworkFileInfo = document.getElementById('frameworkFileInfo');
        const frameworkError = document.getElementById('frameworkError');
        
        const modsDropZone = document.getElementById('modsDropZone');
        const modsFileInput = document.getElementById('modsFileInput');
        const modsBrowseBtn = document.getElementById('modsBrowseBtn');
        const modsFileList = document.getElementById('modsFileList');
        const modsError = document.getElementById('modsError');
        
        const installBtn = document.getElementById('installBtn');
        const installProgress = document.getElementById('installProgress');
        const installProgressFill = document.getElementById('installProgressFill');
        const installProgressText = document.getElementById('installProgressText');
        const installError = document.getElementById('installError');
        const installResult = document.getElementById('installResult');
        const downloadBtn = document.getElementById('downloadBtn');
        
        // 初始化拖放区域
        initDropZone(ipaDropZone, ipaFileInput, handleIpaFile);
        initDropZone(frameworkDropZone, frameworkFileInput, handleFrameworkFile);
        initDropZone(modsDropZone, modsFileInput, handleModFiles);
        
        // 浏览按钮事件
        ipaBrowseBtn.addEventListener('click', () => ipaFileInput.click());
        frameworkBrowseBtn.addEventListener('click', () => frameworkFileInput.click());
        modsBrowseBtn.addEventListener('click', () => modsFileInput.click());
        
        // 文件选择事件
        ipaFileInput.addEventListener('change', (e) => {
            if (e.target.files.length > 0) handleIpaFile(e.target.files[0]);
        });
        
        frameworkFileInput.addEventListener('change', (e) => {
            if (e.target.files.length > 0) handleFrameworkFile(e.target.files[0]);
        });
        
        modsFileInput.addEventListener('change', (e) => {
            if (e.target.files.length > 0) handleModFiles(Array.from(e.target.files));
        });
        
        // 安装按钮事件
        installBtn.addEventListener('click', async () => {
            await installMods();
        });
        
        // 下载按钮事件
        downloadBtn.addEventListener('click', () => {
            if (modifiedIpa) {
                const filename = ipaFile.name.replace('.ipa', '_modded.ipa');
                const blob = new Blob([modifiedIpa], { 
                    type: 'application/octet-stream' 
                });
                saveAs(blob, filename);
            }
        });
        
        // 处理IPA文件
        function handleIpaFile(file) {
            if (!file.name.toLowerCase().endsWith('.ipa')) {
                showError(ipaError, '请选择有效的IPA文件');
                return;
            }
            
            ipaError.style.display = 'none';
            ipaFile = file;
            ipaFileInfo.innerHTML = `已选择: <strong>${file.name}</strong> (${formatFileSize(file.size)})`;
            ipaFileInfo.style.display = 'block';
            checkReadyState();
        }
        
        // 处理框架文件
        function handleFrameworkFile(file) {
            if (!file.name.match(/BM\d+\.\d+\.\d+\(.*\)\.zip/i)) {
                showError(frameworkError, '请选择有效的BM框架文件 (格式应为BMXX.XX.XX(X.XX).zip)');
                return;
            }
            
            frameworkError.style.display = 'none';
            frameworkFile = file;
            frameworkFileInfo.innerHTML = `已选择: <strong>${file.name}</strong> (${formatFileSize(file.size)})`;
            frameworkFileInfo.style.display = 'block';
            checkReadyState();
        }
        
        // 处理模组文件
        function handleModFiles(files) {
            modsError.style.display = 'none';
            modFiles = files.filter(file => 
                file.name.match(/BM\d{3}\.zip/i) || 
                file.name.match(/BM\d+\.\d+\.\d+\(.*\)\.zip/i)
            );
            
            if (modFiles.length === 0) {
                showError(modsError, '未找到有效的BM模组文件 (格式应为BMXXX.zip或BMXX.XX.XX(X.XX).zip)');
                return;
            }
            
            modsFileList.innerHTML = '';
            modFiles.forEach(file => {
                const fileItem = document.createElement('div');
                fileItem.className = 'file-item';
                fileItem.textContent = `${file.name} (${formatFileSize(file.size)})`;
                modsFileList.appendChild(fileItem);
            });
            modsFileList.style.display = 'block';
            checkReadyState();
        }
        
        // 检查是否准备好安装
        function checkReadyState() {
            installBtn.disabled = !(ipaFile && frameworkFile);
        }
        
        // 安装模组
        async function installMods() {
            installError.style.display = 'none';
            installProgress.style.display = 'block';
            installProgressText.textContent = '准备安装...';
            installProgressFill.style.width = '0%';
            
            try {
                // 1. 解压框架和模组文件
                installProgressText.textContent = '正在解压框架和模组...';
                installProgressFill.style.width = '10%';
                
                // 收集所有要添加的文件
                const modFilesToAdd = {
                    '_data': {},  // 对应data.archive
                    '_dlc0002': {} // 对应dlc0002.archive
                };
                
                // 先解压框架
                await extractModFiles(frameworkFile, modFilesToAdd, '20%');
                
                // 再解压模组
                for (let i = 0; i < modFiles.length; i++) {
                    const progress = 20 + (i / modFiles.length) * 30;
                    await extractModFiles(modFiles[i], modFilesToAdd, `${Math.round(progress)}%`);
                }
                
                // 2. 读取IPA文件
                installProgressText.textContent = '正在读取IPA文件...';
                installProgressFill.style.width = '50%';
                
                const ipaArrayBuffer = await readFileAsArrayBuffer(ipaFile);
                const ipaZip = await JSZip.loadAsync(ipaArrayBuffer);
                
                // 3. 提取原始archive文件
                installProgressText.textContent = '正在提取原始游戏数据...';
                installProgressFill.style.width = '60%';
                
                // 查找Payload目录下的.app文件
                let appPath = '';
                for (const filename of Object.keys(ipaZip.files)) {
                    if (filename.includes('Payload/') && filename.endsWith('.app/')) {
                        appPath = filename;
                        break;
                    }
                }
                
                if (!appPath) {
                    throw new Error('找不到Payload目录下的.app文件');
                }
                
                // 提取data.archive和dlc0002.archive
                const dataArchivePath = `${appPath}data.archive`;
                const dlcArchivePath = `${appPath}dlc0002.archive`;
                
                const dataArchiveFile = ipaZip.files[dataArchivePath];
                const dlcArchiveFile = ipaZip.files[dlcArchivePath];
                
                if (!dataArchiveFile || dataArchiveFile.dir) {
                    throw new Error('找不到data.archive文件');
                }
                
                // 4. 解压原始archive文件
                installProgressText.textContent = '正在解压游戏数据...';
                installProgressFill.style.width = '70%';
                
                const dataArchiveData = await dataArchiveFile.async('uint8array');
                const dlcArchiveData = dlcArchiveFile ? await dlcArchiveFile.async('uint8array') : null;
                
                // 使用KLFA解包
                const originalDataFiles = await KLFA.unpack(dataArchiveData);
                const originalDlcFiles = dlcArchiveData ? await KLFA.unpack(dlcArchiveData) : [];
                
                // 5. 合并模组文件
                installProgressText.textContent = '正在合并模组文件...';
                installProgressFill.style.width = '80%';
                
                // 创建合并后的文件集合
                const mergedDataFiles = [...originalDataFiles];
                const mergedDlcFiles = [...originalDlcFiles];
                
                // 添加模组文件到data
                for (const [path, fileData] of Object.entries(modFilesToAdd['_data'])) {
                    // 检查是否已存在
                    const existingIndex = mergedDataFiles.findIndex(f => f.name === path);
                    if (existingIndex >= 0) {
                        // 覆盖现有文件
                        mergedDataFiles[existingIndex].data = fileData;
                    } else {
                        // 添加新文件
                        mergedDataFiles.push({
                            name: path,
                            data: fileData,
                            size: fileData.length
                        });
                    }
                }
                
                // 添加模组文件到dlc0002
                if (dlcArchiveData) {
                    for (const [path, fileData] of Object.entries(modFilesToAdd['_dlc0002'])) {
                        const existingIndex = mergedDlcFiles.findIndex(f => f.name === path);
                        if (existingIndex >= 0) {
                            mergedDlcFiles[existingIndex].data = fileData;
                        } else {
                            mergedDlcFiles.push({
                                name: path,
                                data: fileData,
                                size: fileData.length
                            });
                        }
                    }
                }
                
                // 6. 重新打包archive文件
                installProgressText.textContent = '正在重新打包游戏数据...';
                installProgressFill.style.width = '85%';
                
                const newDataArchive = await KLFA.pack(mergedDataFiles);
                const newDlcArchive = dlcArchiveData ? await KLFA.pack(mergedDlcFiles) : null;
                
                // 7. 更新IPA文件
                installProgressText.textContent = '正在更新IPA文件...';
                installProgressFill.style.width = '90%';
                
                // 删除旧的archive文件
                ipaZip.remove(dataArchivePath);
                if (dlcArchiveFile) {
                    ipaZip.remove(dlcArchivePath);
                }
                
                // 添加新的archive文件
                ipaZip.file(dataArchivePath, newDataArchive);
                if (newDlcArchive) {
                    ipaZip.file(dlcArchivePath, newDlcArchive);
                }
                
                // 8. 生成修改后的IPA
                installProgressText.textContent = '正在生成修改后的IPA...';
                installProgressFill.style.width = '95%';
                
                modifiedIpa = await ipaZip.generateAsync({ type: 'blob' }, (metadata) => {
                    if (metadata.percent) {
                        const progress = 95 + (metadata.percent / 100) * 5;
                        installProgressFill.style.width = `${progress}%`;
                    }
                });
                
                // 完成
                installProgressFill.style.width = '100%';
                installProgressText.textContent = '安装完成！';
                
                // 显示下载按钮
                setTimeout(() => {
                    installResult.style.display = 'block';
                    installResult.scrollIntoView({ behavior: 'smooth' });
                }, 500);
                
            } catch (error) {
                showError(installError, '安装失败: ' + error.message);
                console.error(error);
                installProgressText.textContent = '安装失败';
                installProgressFill.style.width = '0%';
            }
        }
        
        // 从ZIP提取模组文件
        async function extractModFiles(zipFile, modFilesToAdd, progressPercent) {
            installProgressFill.style.width = progressPercent;
            installProgressText.textContent = `正在解压: ${zipFile.name}...`;
            
            const arrayBuffer = await readFileAsArrayBuffer(zipFile);
            const zip = await JSZip.loadAsync(arrayBuffer);
            
            // 查找ADD_TO_OBB文件夹
            let addToObbPrefix = '';
            for (const filename of Object.keys(zip.files)) {
                if (filename.includes('ADD_TO_OBB/') || filename.includes('ADD_TO_OBB\\')) {
                    addToObbPrefix = filename.split('ADD_TO_OBB')[0] + 'ADD_TO_OBB/';
                    break;
                }
            }
            
            if (!addToObbPrefix) {
                console.warn(`未找到ADD_TO_OBB目录: ${zipFile.name}`);
                return;
            }
            
            // 提取文件
            for (const filename of Object.keys(zip.files)) {
                const zipEntry = zip.files[filename];
                if (zipEntry.dir) continue;
                
                // 处理ADD_TO_OBB中的文件
                if (filename.startsWith(addToObbPrefix)) {
                    const relativePath = filename.slice(addToObbPrefix.length);
                    
                    // 根据路径决定添加到哪个archive
                    if (relativePath.startsWith('mods/') || relativePath.startsWith('scripts/')) {
                        // 添加到_data (data.archive)
                        const targetPath = relativePath;
                        const fileData = await zipEntry.async('uint8array');
                        modFilesToAdd['_data'][targetPath] = fileData;
                    } 
                    else if (relativePath.startsWith('DLC0002/')) {
                        // 添加到_dlc0002 (dlc0002.archive)
                        const targetPath = relativePath.replace('DLC0002/', '');
                        const fileData = await zipEntry.async('uint8array');
                        modFilesToAdd['_dlc0002'][targetPath] = fileData;
                    }
                }
            }
        }
        
        // 辅助函数
        function initDropZone(dropZone, fileInput, handler) {
            ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
                dropZone.addEventListener(eventName, preventDefaults, false);
            });
            
            ['dragenter', 'dragover'].forEach(eventName => {
                dropZone.addEventListener(eventName, () => {
                    dropZone.classList.add('drag-over');
                }, false);
            });
            
            ['dragleave', 'drop'].forEach(eventName => {
                dropZone.addEventListener(eventName, () => {
                    dropZone.classList.remove('drag-over');
                }, false);
            });
            
            dropZone.addEventListener('drop', (e) => {
                const dt = e.dataTransfer;
                if (dt.files.length > 0) {
                    if (fileInput.multiple) {
                        handler(Array.from(dt.files));
                    } else {
                        handler(dt.files[0]);
                    }
                }
            });
        }
        
        function preventDefaults(e) {
            e.preventDefault();
            e.stopPropagation();
        }
        
        function showError(element, message) {
            element.textContent = message;
            element.style.display = 'block';
        }
        
        function formatFileSize(bytes) {
            if (bytes < 1024) return bytes + ' B';
            else if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
            else return (bytes / 1048576).toFixed(1) + ' MB';
        }
        
        function readFileAsArrayBuffer(file) {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = () => resolve(reader.result);
                reader.onerror = reject;
                reader.readAsArrayBuffer(file);
            });
        }
    });
</script>