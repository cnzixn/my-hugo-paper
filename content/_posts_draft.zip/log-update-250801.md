---
title: '框架 - 八月更新'
date: 2025-07-30
author: 'Bny'
summary: '框架BM25.08.01版本更新，请注意查收！'
tags:
- '公告'
- '框架'
comments: false
weight: -8
url: '/p/817/'
---

> 框架 BM25.08.01 版本相关

{{< bili2 BV1CF8dzRE1N >}}

---


- 兼容 iOS 版本。(暂未公开)
